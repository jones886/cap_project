import functions_framework
import datetime
import pandas as pd
import akshare as ak
from google.cloud import storage
import pytz
import tzlocal


@functions_framework.http
def latest_price(request):
    local_timezone = tzlocal.get_localzone()
    local_time = datetime.datetime.now(local_timezone)
    target_timezone = pytz.timezone('Asia/Shanghai')
    target_time = local_time.astimezone(target_timezone)
    tradeDate = target_time.strftime('%Y%m%d_%H:%M:%S')

    storage_client = storage.Client(project='cap-project-ninja-7')
    bucket = storage_client.bucket('cap_project')
    stock_zh_a_spot_em_df = ak.stock_zh_a_spot_em()
    column_names = [
        'Serial Number', 
        'Code', 
        'Name', 
        'Latest Price', 
        'Change Percentage', 
        'Change Amount', 
        'Volume', 
        'Turnover', 
        'Amplitude', 
        'Highest', 
        'Lowest', 
        'Open Today', 
        'Close Yesterday', 
        'Volume Ratio', 
        'Turnover Rate', 
        'PE Ratio', 
        'PB Ratio', 
        'Total Market Cap', 
        'Circulating Market Cap', 
        'Price Increase Rate', 
        '5_Minute Change', 
        '60_Day Change', 
        'Year_to_Date Change'
    ]
    stock_zh_a_spot_em_df.columns = column_names
    stock_zh_a_spot_em_df = stock_zh_a_spot_em_df.drop('Name', axis = 1)
    stock_zh_a_spot_em_df['trade_time'] = target_time.now()
    csv_file = stock_zh_a_spot_em_df.to_csv(index=False)
    filename = 'LATEST_PRICE/latest_price_' + tradeDate + '.csv'
    
    # # Save Data in JSON file to Cloud Storage
    blob =bucket.blob(filename)
    blob.upload_from_string(csv_file)
    return """<p>"status 200"</p>"""