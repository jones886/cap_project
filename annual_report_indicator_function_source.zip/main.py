import base64
import functions_framework
from google.cloud import storage
from google.cloud import bigquery
import pandas as pd
import io
import tushare as ts
import datetime
import tzlocal
import pytz

# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def annual_report_indicators(cloud_event):
    # Print out the data from Pub/Sub, to prove that it worked
    print(base64.b64decode(cloud_event.data["message"]["data"]))
    local_timezone = tzlocal.get_localzone()
    local_time = datetime.datetime.now(local_timezone)
    target_timezone = pytz.timezone('Asia/Shanghai')
    target_time = local_time.astimezone(target_timezone)
    tradeDate = target_time.strftime('%Y%m%d')

    pro = ts.pro_api('744aa43e07fa5cf1f2b4e83f5b64002904d7fe802d5a54a49331d3f1')
    
    storage_client = storage.Client(project='cap-project-ninja-7')
    bucket = storage_client.bucket('cap_project')

    project_id = 'cap-project-ninja-7'
    client = bigquery.Client(project=project_id)

    sql = """
    SELECT * FROM cap-project-ninja-7.CAP_PROJECT.DCF_FILTERED
    """
    df = client.query(sql).to_dataframe()
    stock_list = df['stockcode'].tolist()
    
    report_period = str(int(tradeDate[:4])-1) + "1231"
    df_annual = pd.DataFrame()
    first_annual_kpi = pro.query('fina_indicator_vip', period=report_period, ts_code = stock_list[0], fields='ts_code, profit_dedt, grossprofit_margin, debt_to_assets, ocf_to_profit, rd_exp')
    df_annual = pd.concat([df_annual, first_annual_kpi])

    for stock_code in stock_list[1:]:
      annual_kpi = pro.query('fina_indicator_vip', period=report_period, ts_code = stock_code, fields='ts_code, profit_dedt, grossprofit_margin, debt_to_assets, ocf_to_profit, rd_exp')
      df_annual = pd.concat([df_annual, annual_kpi], ignore_index=True)

    csv_file = df_annual.to_csv(index=False)
    filename = 'ANNUAL_INDICATORS/annual_indicators_' + tradeDate + '.csv'
    blob_upload =bucket.blob(filename)
    blob_upload.upload_from_string(csv_file)
    return """<p>"status 200"</p>"""  


