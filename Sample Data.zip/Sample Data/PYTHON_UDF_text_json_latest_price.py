import json

def process(value):
    data = value.split(',')
    obj = {
        'Serial Number': data[0], 
        'Code': data[1], 
        'Name': data[2], 
        'Latest Price': data[3], 
        'Change Percentage': data[4], 
        'Change Amount': data[5], 
        'Volume': data[6], 
        'Turnover': data[7], 
        'Amplitude': data[8], 
        'Highest': data[9], 
        'Lowest': data[10], 
        'Open Today': data[11], 
        'Close Yesterday': data[12], 
        'Volume Ratio': data[13], 
        'Turnover Rate': data[14], 
        'PE Ratio': data[15], 
        'PB Ratio': data[16], 
        'Total Market Cap': data[17], 
        'Circulating Market Cap': data[18], 
        'Price Increase Rate': data[19], 
        '5_Minute Change': data[20], 
        '60_Day Change': data[21], 
        'Year_to_Date Change': data[22]
    }
    return json.dumps(obj)
