import base64
import functions_framework
from google.cloud import storage
from google.cloud import bigquery
import pandas as pd
import io
import tushare as ts
import datetime
import tzlocal
import pytz

# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def stock_daily_360(cloud_event):
    # Print out the data from Pub/Sub, to prove that it worked
    print(base64.b64decode(cloud_event.data["message"]["data"]))
    local_timezone = tzlocal.get_localzone()
    local_time = datetime.datetime.now(local_timezone)
    target_timezone = pytz.timezone('Asia/Shanghai')
    target_time = local_time.astimezone(target_timezone)
    tradeDate = target_time.strftime('%Y%m%d')

    time_range = datetime.datetime.strftime(
            (datetime.datetime.today()-datetime.timedelta(days=360)).date(), '%Y%m%d')

    # Print out the data from Pub/Sub, to prove that it worked
    pro = ts.pro_api('')
    
    storage_client = storage.Client(project='cap-project-ninja-7')
    bucket = storage_client.bucket('cap_project')

    project_id = 'cap-project-ninja-7'
    client = bigquery.Client(project=project_id)

    sql = """
    SELECT * FROM cap-project-ninja-7.CAP_PROJECT.DCF_FILTERED
    """
    df = client.query(sql).to_dataframe()
    stock_list = df['stockcode'].tolist()
    
    df_daily = pd.DataFrame()
    df_sz_daily = pro.index_daily(ts_code='399300.SZ', start_date=time_range,
                            end_date=tradeDate).sort_values(by='trade_date')
    df_daily = pd.concat([df_daily, df_sz_daily])
    for stock_code in stock_list:
        df_stock_daily = pro.daily(ts_code=stock_code, start_date=time_range, end_date=tradeDate).sort_values(by='trade_date')
        df_daily = pd.concat([df_daily, df_stock_daily], ignore_index=True)

    

    df_sh_daily = pro.index_daily(ts_code='000001.SH', start_date=time_range,
                                end_date=tradeDate).sort_values(by='trade_date')
    df_daily = pd.concat([df_daily, df_sh_daily], ignore_index=True)

    csv_file = df_daily.to_csv(index=False)
    filename = 'STOCK_DAILY/df_daily_' + tradeDate + '.csv'
    blob_upload =bucket.blob(filename)
    blob_upload.upload_from_string(csv_file)
    return """<p>"status 200"</p>"""
