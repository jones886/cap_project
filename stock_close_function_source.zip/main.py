import functions_framework
import datetime
import pandas as pd
import tushare as ts
from google.cloud import storage
import pytz
import tzlocal


@functions_framework.http
def stock_close(request):
    local_timezone = tzlocal.get_localzone()
    local_time = datetime.datetime.now(local_timezone)
    target_timezone = pytz.timezone('Asia/Shanghai')
    target_time = local_time.astimezone(target_timezone)
    tradeDate = target_time.strftime('%Y%m%d')

    storage_client = storage.Client(project='cap-project-ninja-7')
    bucket = storage_client.bucket('cap_project')
    pro = ts.pro_api('')    
    df = pro.bak_daily(trade_date=tradeDate, fields='ts_code, close, pe, activity, strength, vol, total_mv')
    df['trade_date'] = target_time.date()
    csv_file = df.to_csv(index=False)
    filename = 'STOCK_CLOSE/stock_close_' + tradeDate + '.csv'
    # # Save Data in JSON file to Cloud Storage
    blob =bucket.blob(filename)
    blob.upload_from_string(csv_file)
    return """<p>"status 200"</p>"""
