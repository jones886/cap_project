import base64
import functions_framework
from google.cloud import bigquery
from google.cloud import storage
import datetime
import pandas as pd
import pytz
import tzlocal


# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def dcf_filtered(cloud_event):
  local_timezone = tzlocal.get_localzone()
  local_time = datetime.datetime.now(local_timezone)
  target_timezone = pytz.timezone('Asia/Shanghai')
  target_time = local_time.astimezone(target_timezone)
  tradeDate = target_time.strftime('%Y%m%d')

  storage_client = storage.Client(project='cap-project-ninja-7')
  bucket = storage_client.bucket('cap_project')
  project_id = 'cap-project-ninja-7'
  client = bigquery.Client(project=project_id)

  sql = """
  SELECT * FROM cap-project-ninja-7.CAP_PROJECT.DCF
  """
  df_dcf = client.query(sql).to_dataframe()

  sql = """
  SELECT ts_code, close FROM cap-project-ninja-7.CAP_PROJECT.STOCK_CLOSE
  """

  df_stock_close = client.query(sql).to_dataframe()
  df_stock_close = df_stock_close.rename(columns={'ts_code':'stockcode'})

  df_dcf_price = df_dcf.merge(df_stock_close, on='stockcode', how='left')
  df_dcf_price = df_dcf_price.dropna(subset='DCF')
  df_dcf_price['DCF_ratio'] = df_dcf_price['DCF'] / df_dcf_price['close']
  df_dcf_price = df_dcf_price[(df_dcf_price['DCF_ratio'] > 1.2) & (df_dcf_price['close'] > 20)]
  df_dcf_price['trade_date'] = target_time.date()
  csv_file = df_dcf_price.to_csv(index=False)
  filename = 'DCF_FILTERED/dcf_filtered_' + tradeDate + '.csv'
  # # Save Data in JSON file to Cloud Storage
  blob =bucket.blob(filename)
  blob.upload_from_string(csv_file)
  return """<p>"status 200"</p>"""