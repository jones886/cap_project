import base64
import functions_framework
from google.cloud import storage
from google.cloud import bigquery
import pandas as pd
import io
import tushare as ts
import datetime
import tzlocal
import pytz

# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def filtered_fin_indicators(cloud_event):
    # Print out the data from Pub/Sub, to prove that it worked
    print(base64.b64decode(cloud_event.data["message"]["data"]))
    local_timezone = tzlocal.get_localzone()
    local_time = datetime.datetime.now(local_timezone)
    target_timezone = pytz.timezone('Asia/Shanghai')
    target_time = local_time.astimezone(target_timezone)
    tradeDate = target_time.strftime('%Y%m%d')

    pro = ts.pro_api('744aa43e07fa5cf1f2b4e83f5b64002904d7fe802d5a54a49331d3f1')
    
    storage_client = storage.Client(project='cap-project-ninja-7')
    bucket = storage_client.bucket('cap_project')

    project_id = 'cap-project-ninja-7'
    client = bigquery.Client(project=project_id)

    sql = """
    SELECT * FROM cap-project-ninja-7.CAP_PROJECT.DCF_FILTERED
    """
    df = client.query(sql).to_dataframe()
    stock_list = df['stockcode'].tolist()
    
    df_fin_indicator = pd.DataFrame()
    q1_report_period = tdtext[:4] + "0331"
    q2_report_period = tdtext[:4] + "0630"
    q3_report_period = tdtext[:4] + "0930"
    q4_report_period = str(int(tdtext[:4])-1) + "1231"
    for stock_code in stock_list:
        if int(tdtext[4:6]) >= 1 and int(tdtext[4:6]) <= 3:
            quarter_kpi = pro.query('fina_indicator_vip', period=q4_report_period, ts_code = stock_code, fields='ts_code, q_gr_yoy, q_op_yoy, q_profit_yoy, eps, ocfps')
            if len(q4_kpi) != 0:
                quarter_kpi = q4_kpi.fillna(0)
            else:
                quarter_kpi = pro.query('fina_indicator_vip', period=q3_report_period, ts_code = stock_code, fields='ts_code, q_gr_yoy, q_op_yoy, q_profit_yoy, eps, ocfps')
        elif int(tdtext[4:6]) >=4 and int(tdtext[4:6]) <= 6:       
            quarter_kpi = pro.query('fina_indicator_vip', period=q1_report_period, ts_code = stock_code, fields='ts_code, q_gr_yoy, q_op_yoy, q_profit_yoy, eps, ocfps')
            if len(quarter_kpi) != 0:
                quarter_kpi = quarter_kpi.fillna(0)
            else:
                pass
        elif int(tdtext[4:6]) >=7 and int(tdtext[4:6]) <= 9:
            quarter_kpi = pro.query('fina_indicator_vip', period=q2_report_period, ts_code = stock_code, fields='ts_code, q_gr_yoy, q_op_yoy, q_profit_yoy, eps, ocfps')
            if len(quarter_kpi) != 0:
                quarter_kpi = quarter_kpi.fillna(0)
            else:
                quarter_kpi = pro.query('fina_indicator_vip', period=q1_report_period, ts_code = stock_code, fields='ts_code, q_gr_yoy, q_op_yoy, q_profit_yoy, eps, ocfps')
        elif int(tdtext[4:6]) >=10 and int(tdtext[4:6]) <= 11:
            quarter_kpi = pro.query('fina_indicator_vip', period=q3_report_period, ts_code = stock_code, fields='ts_code, q_gr_yoy, q_op_yoy, q_profit_yoy, eps, ocfps')
            if len(quarter_kpi) != 0:
                quarter_kpi = quarter_kpi.fillna(0)
            else:
                quarter_kpi = pro.query('fina_indicator_vip', period=q1_report_period, ts_code = stock_code, fields='ts_code, q_gr_yoy, q_op_yoy, q_profit_yoy, eps, ocfps')
        else:
            pass
        df_fin_indicator = pd.concat([df_fin_indicator, quarter_kpi.iloc[0]], axis=1)

    df_fin_indicator = quarter_report_indicators(pro, stock_list, tdtext)
    csv_file = df_fin_indicator.to_csv(index=False)
    filename = 'FILTERED_FIN_INDICATORS/dcf_filtered_fin_indicators_' + tradeDate + '.csv'
    blob_upload =bucket.blob(filename)
    blob_upload.upload_from_string(csv_file)
    return """<p>"status 200"</p>"""